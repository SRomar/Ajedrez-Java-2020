package Principal;

import GUI.Mesa;
import Tablero.Tablero;

public class Ejecutable {

	public static void main(String[] args) {

		//Tablero tablero = Tablero.crearTableroBase();

		//System.out.println(tablero);
		
		Mesa mesa = new Mesa();
	}

}
